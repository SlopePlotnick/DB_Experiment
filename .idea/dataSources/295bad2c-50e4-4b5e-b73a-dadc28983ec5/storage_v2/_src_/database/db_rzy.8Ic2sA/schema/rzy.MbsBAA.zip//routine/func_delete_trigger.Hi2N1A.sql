create function func_delete_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
  IF TG_OP = 'DELETE' THEN
    UPDATE t_goods set price = (price + OLD.money) WHERE id = OLD.gid;
    RETURN OLD;
  END IF;
  RETURN OLD;
END;
$$;

alter function func_delete_trigger() owner to rzy;

