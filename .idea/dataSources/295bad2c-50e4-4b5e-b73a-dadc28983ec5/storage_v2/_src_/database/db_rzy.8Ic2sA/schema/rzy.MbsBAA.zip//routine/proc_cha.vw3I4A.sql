create function proc_cha(p_name character varying)
    returns TABLE(id character varying, name character varying, price integer)
    language plpgsql
as
$$
		BEGIN
			return query SELECT * FROM t_goods WHERE name = p_name;
		END;
		$$;

alter function proc_cha(varchar) owner to rzy;

