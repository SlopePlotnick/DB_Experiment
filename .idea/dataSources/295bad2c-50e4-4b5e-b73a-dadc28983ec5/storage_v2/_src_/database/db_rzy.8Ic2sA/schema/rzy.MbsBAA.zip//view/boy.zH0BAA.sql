create view boy(sno, sname, cname, grade) as
SELECT s.sno, s.sname, c.cname, sc.grade
FROM s,
     sc,
     c
WHERE s.ssex = '男'::bpchar
  AND s.sno = sc.sno
  AND c.cno = sc.cno;

alter table boy
    owner to rzy;

