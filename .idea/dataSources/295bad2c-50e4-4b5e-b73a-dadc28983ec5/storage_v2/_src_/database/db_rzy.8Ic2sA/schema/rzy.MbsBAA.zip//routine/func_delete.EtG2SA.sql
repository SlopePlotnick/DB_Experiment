create function func_delete("p_商品id" character varying) returns void
    language plpgsql
as
$$
		BEGIN
			DELETE FROM t_goods WHERE id = p_商品id;
		END;
		$$;

alter function func_delete(varchar) owner to rzy;

