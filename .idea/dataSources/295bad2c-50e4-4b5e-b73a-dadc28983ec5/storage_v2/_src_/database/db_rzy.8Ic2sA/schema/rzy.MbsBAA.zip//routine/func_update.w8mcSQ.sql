create function func_update() returns trigger
    language plpgsql
as
$$
BEGIN
  IF TG_OP = 'UPDATE' THEN
    UPDATE t_goods set price = (price + OLD.money) WHERE id = OLD.gid;
    UPDATE t_goods set price = (price - NEW.money) WHERE id = NEW.gid;
    RETURN OLD;
  END IF;
  RETURN OLD;
END;
$$;

alter function func_update() owner to rzy;

