create function func_insert() returns trigger
    language plpgsql
as
$$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE t_goods set price = (price - NEW.money) WHERE id = new.gid;
    RETURN NEW;
  END IF;
  RETURN NEW;
END;
$$;

alter function func_insert() owner to rzy;

